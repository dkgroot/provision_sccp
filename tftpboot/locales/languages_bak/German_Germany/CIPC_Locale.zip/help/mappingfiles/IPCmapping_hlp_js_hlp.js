if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Cisco IP Communicator-Online-Hilfe
// 
//Copyright � 2003-2006, Cisco Systems, Inc. Alle Rechte vorbehalten.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Benutzereinstellungen
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#477695";

// Netzwerkeinstellungen
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#477737";

// Audioeinstellungen
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#477775";

// Netzwerk-Audioeinstellungen
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#477926";

// Erweiterte Audioeinstellungen
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#477964";

// Verzeichniseinstellungen
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#477996";

// Schnellsuche verwenden
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#391500";

