if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Cisco IP Communicator - Onlinehilfe
// 
//Copyright � 2009, Cisco Systems, Inc. Alle Rechte vorbehalten.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Benutzereinstellungen 
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp88649";

// Netzwerkeinstellungen 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp88680";

// Audioeinstellungen 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp88709";

// Netzwerk-Audioeinstellungen 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp88963";

// Erweiterte Audioeinstellungen 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp88998";

// Verzeichniseinstellungen 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp89025";

// Verwenden der Schnellsuche 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp314832";

