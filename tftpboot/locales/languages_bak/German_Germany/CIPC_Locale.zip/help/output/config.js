//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Verwenden der Hilfe ";

//Application title. This will be the title of index.html
var appTitle = "Cisco IP Communicator - Onlinehilfe";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Zur�ck";

//Label for close function
var close = "";

//label for contents tab
var contents = "Inhalt";

//label for contents collpase 
var collapse = "Alle ausblenden";

//label for V4 search button
var doSearch = "Los";

//label for contents expand
var expand = "Alle einblenden";

//label for favorites
var favorites = "Favoriten";

//label for favorites add button
var favAdd = "Hinzuf�gen";

//label for favorites enter field
var favEnter = "Aktuelles Thema:";

//label for favorites remove button
var favRemove = "Entfernen";

//label for feedback
var feedback = "Feedback";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Weiter";

//label for glossay
var glossary = "Glossar";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Ausblenden";

//label for "go to top toc"
var home = "Startseite";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "Index";

//label for index enter field
var indexEnter = "Geben Sie das Schl�sselwort ein:";

//label for index popup when no URL
var indexPopup = "Um Informationen zu diesem Schl�sselwort zu suchen, w�hlen Sie einen Eintrag in der Liste aus.";

//label for pdf
var pdf = "PDF anzeigen";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Drucken";

//label for search
var search = "Suchen";

//search group, should be the same appears in mappingfile
var searchGroup = "Alle";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Optional";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Anzeigen";

//default start page
var startPage = "ipcuggs1.html";
 
