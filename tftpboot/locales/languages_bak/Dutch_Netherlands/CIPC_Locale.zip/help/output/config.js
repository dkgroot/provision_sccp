//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Help gebruiken";

//Application title. This will be the title of index.html
var appTitle = "Help voor Cisco IP Communicator";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Terug";

//Label for close function
var close = "";

//label for contents tab
var contents = "Inhoud";

//label for contents collpase 
var collapse = "Alles samenvouwen";

//label for V4 search button
var doSearch = "Start";

//label for contents expand
var expand = "Alles uitvouwen";

//label for favorites
var favorites = "Favorieten";

//label for favorites add button
var favAdd = "Toevoegen";

//label for favorites enter field
var favEnter = "Huidige onderwerp:";

//label for favorites remove button
var favRemove = "Verwijderen";

//label for feedback
var feedback = "Feedback";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Volgende";

//label for glossay
var glossary = "Woordenlijst";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Verbergen";

//label for "go to top toc"
var home = "Startpagina";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "Index";

//label for index enter field
var indexEnter = "Typ het woord dat u zoekt:";

//label for index popup when no URL
var indexPopup = "Voor informatie over dit zoekwoord selecteert u een van de items in de lijst.";

//label for pdf
var pdf = "PDF weergeven";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Afdrukken";

//label for search
var search = "Zoeken";

//search group, should be the same appears in mappingfile
var searchGroup = "All";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Optioneel";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Weergeven";

//default start page
var startPage = "ipcuggs1.html";
