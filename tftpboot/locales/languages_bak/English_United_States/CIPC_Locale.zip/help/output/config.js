//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Using Help";

//Application title. This will be the title of index.html
var appTitle = "Cisco IP Communicator Online Help";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Back";

//Label for close function
var close = "";

//label for contents tab
var contents = "Contents";

//label for contents collpase 
var collapse = "Collapse All";

//label for V4 search button
var doSearch = "Go";

//label for contents expand
var expand = "Expand All";

//label for favorites
var favorites = "Favorites";

//label for favorites add button
var favAdd = "Add";

//label for favorites enter field
var favEnter = "Current Topic:";

//label for favorites remove button
var favRemove = "Remove";

//label for feedback
var feedback = "Feedback";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Forward";

//label for glossay
var glossary = "Glossary";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Hide";

//label for "go to top toc"
var home = "Home";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "Index";

//label for index enter field
var indexEnter = "Type the keyword to find:";

//label for index popup when no URL
var indexPopup = "To locate information about this keyword, please select one of the subentries in the list.";

//label for pdf
var pdf = "View PDF";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Print";

//label for search
var search = "Search";

//search group, should be the same appears in mappingfile
var searchGroup = "All";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Optional";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Show";

//default start page
var startPage = "ipcuggs1.html";
