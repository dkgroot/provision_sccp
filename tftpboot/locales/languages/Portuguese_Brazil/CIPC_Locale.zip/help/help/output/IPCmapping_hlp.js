if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Ajuda online do Cisco IP Communicator
// 
//Copyright � 2009, Cisco Systems, Inc. Todos os direitos reservados.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Defini��es do usu�rio 
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp310394";

// Defini��es da rede 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp310425";

// Defini��es de �udio 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp310454";

// Defini��es de �udio da rede 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp310708";

// Defini��es avan�adas de �udio 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp310743";

// Defini��es de diret�rios 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp310770";

// Usar o recurso Pesquisa r�pida 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp15352";

