if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Ajuda on-line do Cisco IP Communicator
// 
//Copyright � 2003-2006, Cisco Systems, Inc. Todos os direitos reservados.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Defini��es do usu�rio
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#901934";

// Defini��es da rede
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#901976";

// Defini��es de �udio
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#902014";

// Defini��es de �udio da rede
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#902165";

// Defini��es avan�adas de �udio
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#902203";

// Defini��es de diret�rios
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#902235";

// Usando a fun��o Pesquisa r�pida
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#265510";

