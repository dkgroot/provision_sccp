if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Aide en ligne de Cisco IP Communicator
// 
//Copyright � 2003-2006, Cisco Systems, Inc. Tous droits r�serv�s.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Param�tres utilisateur
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#537950";

// Param�tres r�seau
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#537992";

// Param�tres audio
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#538030";

// Param�tres audio r�seau
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#538181";

// Param�tres audio avanc�s
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#538219";

// Param�tres de r�pertoire
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#538251";

// Utilisation de la fonction Recherche rapide
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#10234";

