if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Aide en ligne de Cisco IP Communicator
// 
//Copyright � 2009, Cisco Systems, Inc. Tous droits r�serv�s.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Param�tres utilisateur 
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp32328";

// Param�tres r�seau 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp32359";

// Param�tres audio 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp32388";

// Param�tres audio du r�seau 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp32642";

// Param�tres audio avanc�s 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp32677";

// Param�tres de r�pertoire 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp32704";

// Utilisation de la fonction Recherche rapide 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp411683";

