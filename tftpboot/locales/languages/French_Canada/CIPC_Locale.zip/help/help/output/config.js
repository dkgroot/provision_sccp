//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Utilisation de l'Aide";

//Application title. This will be the title of index.html
var appTitle = "Aide en ligne de Cisco IP Communicator";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Pr�c�dent";

//Label for close function
var close = "";

//label for contents tab
var contents = "Table des mati�res";

//label for contents collpase 
var collapse = "R�duire tout";

//label for V4 search button
var doSearch = "Valider";

//label for contents expand
var expand = "D�velopper tout";

//label for favorites
var favorites = "Favoris";

//label for favorites add button
var favAdd = "Ajouter";

//label for favorites enter field
var favEnter = "Rubrique actuelle :";

//label for favorites remove button
var favRemove = "Supprimer";

//label for feedback
var feedback = "Commentaires";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Transf�rer";

//label for glossay
var glossary = "Glossaire";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Masquer";

//label for "go to top toc"
var home = "Accueil";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "Index";

//label for index enter field
var indexEnter = "Saisissez le mot-cl� recherch� :";

//label for index popup when no URL
var indexPopup = "Pour rechercher des informations sur ce mot-cl�, veuillez s�lectionner une sous-entr�e dans la liste.";

//label for pdf
var pdf = "Afficher le fichier PDF";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Imprimer";

//label for search
var search = "Rechercher";

//search group, should be the same appears in mappingfile
var searchGroup = "Tous";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Facultatif";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Afficher";

//default start page
var startPage = "ipcuggs1.html";
