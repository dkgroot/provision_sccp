﻿//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "استخدام التعليمات";

//Application title. This will be the title of index.html
var appTitle = "تعليمات Cisco IP Communicator عبر الإنترنت";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "الخلف";

//Label for close function
var close = "";

//label for contents tab
var contents = "المحتويات";

//label for contents collpase 
var collapse = "طي الكل";

//label for V4 search button
var doSearch = "انتقال";

//label for contents expand
var expand = "توسيع الكل";

//label for favorites
var favorites = "المفضلة";

//label for favorites add button
var favAdd = "إضافة";

//label for favorites enter field
var favEnter = "الموضوع الحالي:";

//label for favorites remove button
var favRemove = "إزالة";

//label for feedback
var feedback = "ملاحظات";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "الأمام";

//label for glossay
var glossary = "المصطلحات";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "إخفاء";

//label for "go to top toc"
var home = "الصفحة الرئيسية";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "الفهرس";

//label for index enter field
var indexEnter = "اكتب الكلمة الأساسية للعثور على:";

//label for index popup when no URL
var indexPopup = "لتعيين معلومات حول هذه الكلمة الأساسية، يرجى تحديد أحد الإدخالات الفرعية الموجودة في القائمة.";

//label for pdf
var pdf = "عرض PDF";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "طباعة";

//label for search
var search = "البحث";

//search group, should be the same appears in mappingfile
var searchGroup = "الكل";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "اختياري";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "إظهار";

//default start page
var startPage = "ipcuggs1.html";
