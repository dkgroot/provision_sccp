if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Direkthj�lp f�r Cisco IP Communicator
// 
//Copyright � 2003-2006 Cisco Systems, Inc. Med ensamr�tt.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Anv�ndarinst�llningar
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#165278";

// N�tverksinst�llningar
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#165320";

// Ljudinst�llningar
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#165358";

// N�tverksljudinst�llningar
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#165509";

// Avancerade ljudinst�llningar
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#165547";

// Kataloginst�llningar
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#165579";

// Anv�nda funktionen Snabbs�k
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#1006691";

