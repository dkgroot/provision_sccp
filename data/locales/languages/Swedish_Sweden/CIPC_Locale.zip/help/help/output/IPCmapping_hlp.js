if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Direkthj�lp f�r Cisco IP Communicator
// 
//Copyright � 2009, Cisco Systems, Inc. Med ensamr�tt.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Anv�ndarinst�llningar 
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp229604";

// N�tverksinst�llningar 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp229635";

// Ljudinst�llningar 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp229664";

// N�tverksljudinst�llningar 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp229918";

// Avancerade ljudinst�llningar 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp229953";

// Kataloginst�llningar 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp229980";

// Anv�nda funktionen Snabbs�k 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp771660";

