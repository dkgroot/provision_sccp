//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Utilizzo della Guida in linea";

//Application title. This will be the title of index.html
var appTitle = "Guida in linea di Cisco Unified Personal Communicator";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Indietro";

//Label for close function
var close = "";

//label for contents tab
var contents = "Sommario";

//label for contents collpase 
var collapse = "Comprimi tutto";

//label for V4 search button
var doSearch = "Vai";

//label for contents expand
var expand = "Espandi tutto";

//label for favorites
var favorites = "Preferiti";

//label for favorites add button
var favAdd = "Aggiungi";

//label for favorites enter field
var favEnter = "Argomento corrente:";

//label for favorites remove button
var favRemove = "Rimuovi";

//label for feedback
var feedback = "Feedback";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Avanti";

//label for glossay
var glossary = "Glossario";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Nascondi";

//label for "go to top toc"
var home = "Pagina principale";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "Indice";

//label for index enter field
var indexEnter = "Immettere la parola chiave da cercare:";

//label for index popup when no URL
var indexPopup = "Per ottenere informazioni relativamente alla parola chiave, selezionare una delle voci nell'elenco.";

//label for pdf
var pdf = "Visualizza PDF";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Stampa";

//label for search
var search = "Cerca";

//search group, should be the same appears in mappingfile
var searchGroup = "Tutti";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Facoltativo";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Mostra";

//default start page
var startPage = "ipcuggs1.html";
