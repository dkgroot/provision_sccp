if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Guida in linea di Cisco IP Communicator
// 
//Copyright � 2009, Cisco Systems, Inc. Tutti i diritti riservati.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Impostazioni utente 
mapSet[mapSet.length] = "preferenze utente /output/ipcugset07.html#wp1017779";

// Impostazioni di rete 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp372950";

// Impostazioni audio 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp372979";

// Impostazioni audio di rete 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp373233";

// Impostazioni audio avanzate 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp373268";

// Impostazioni delle rubriche 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp373295";

// Uso della funzione Ricerca rapida 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp984228";

