if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Guida in linea di Cisco IP Communicator
// 
//Copyright � 2003-2006, Cisco Systems, Inc. Tutti i diritti riservati.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Impostazioni utente
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#738002";

// Impostazioni di rete
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#738044";

// Impostazioni audio
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#738082";

// Impostazioni audiodi rete
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#738233";

// Impostazione audio avanzate
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#738271";

// Impostazioni delle rubriche
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#738303";

// Uso della funzione Ricerca rapida
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#143510";

