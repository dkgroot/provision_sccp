if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Gu�a del usuario de Cisco IP Communicator
// 
//Copyright � 2003-2006, Cisco Systems, Inc. Reservados todos los derechos.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Configuraci�n de usuario
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#328826";

// Configuraci�n de red
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#328868";

// Configuraci�n de audio
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#328906";

// Configuraci�n de audio de red
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#329057";

// Configuraci�n de audio avanzada
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#329095";

// Configuraci�n de directorios
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#329127";

// Utilizaci�n de la funci�n de b�squeda r�pida
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#424404";

