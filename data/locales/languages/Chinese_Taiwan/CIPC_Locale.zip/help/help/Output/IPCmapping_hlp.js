if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Cisco IP Communicator Online Help
// 
//Copyright &#169; 2009, Cisco Systems, Inc. All rights reserved.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// �ϥΪ̳]�w
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp559106";

// �����]�w
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp559137";

// ���T�]�w
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp559166";

// �������T�]�w
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp559420";

// �i�����T�]�w
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp559455";

// �ؿ��]�w
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp559482";

// �ϥΧֳt�j�M�\��
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp977657";

