if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Onlinehj�lp til Cisco IP Communicator
// 
//Copyright � 2009 Cisco Systems, Inc. Alle rettigheder forbeholdt.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Brugerindstillinger 
mapSet[mapSet.length] = "prefuser /output/ipcugset07.html#wp575829";

// Netv�rksindstillinger 
mapSet[mapSet.length] = "prefnetwrk /output/ipcugset08.html#wp575860";

// Lydindstillinger 
mapSet[mapSet.length] = "prefaudio /output/ipcugset09.html#wp575889";

// Lydindstillinger for netv�rk 
mapSet[mapSet.length] = "netaudio /output/ipcugset14.html#wp576143";

// Avancerede lydindstillinger 
mapSet[mapSet.length] = "advaudio /output/ipcugset15.html#wp576178";

// Indstillinger for telefonb�ger 
mapSet[mapSet.length] = "prefdirs /output/ipcugset16.html#wp576205";

// S�dan bruger du funktionen Lyns�gning 
mapSet[mapSet.length] = "qsearch /output/ipcugvm7.html#wp523445";

