if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping_hlp.js.hlp
// application:  Online-hj�lp til Cisco IP Communicator
// 
//Copyright � 2003-2006, Cisco Systems, Inc. Alle rettigheder forbeholdes.                      
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// Brugerindstillinger
mapSet[mapSet.length] = "prefuser /output/ipcF408.html#183814";

// Netv�rksindstillinger
mapSet[mapSet.length] = "prefnetwrk /output/ipcF409.html#183856";

// Lydindstillinger
mapSet[mapSet.length] = "prefaudio /output/ipcF410.html#183894";

// Lydindstillinger for netv�rk
mapSet[mapSet.length] = "netaudio /output/ipcF412.html#184045";

// Avancerede lydindstillinger
mapSet[mapSet.length] = "advaudio /output/ipcF413.html#184083";

// Indstillinger for telefonb�ger
mapSet[mapSet.length] = "prefdirs /output/ipcF414.html#184115";

// Brug af funktionen Lyns�gning
mapSet[mapSet.length] = "qsearch /output/ipcF64.html#810234";

