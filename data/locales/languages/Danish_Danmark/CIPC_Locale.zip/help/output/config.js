//navigation frame 'open'(version 4)
top.framesOn = true;

//Label for help on help
var about = "Brug af Hj�lp";

//Application title. This will be the title of index.html
var appTitle = "Onlinehj�lp til Cisco IP Communicator";

//Application runtime path under the help folder.
var appPath = "output";

//label for toolbar back button
var back = "Tilbage";

//Label for close function
var close = "";

//label for contents tab
var contents = "Indhold";

//label for contents collpase 
var collapse = "Skjul alle";

//label for V4 search button
var doSearch = "G�";

//label for contents expand
var expand = "Udvid alle";

//label for favorites
var favorites = "Foretrukne";

//label for favorites add button
var favAdd = "Tilf�j";

//label for favorites enter field
var favEnter = "Aktuelt emne";

//label for favorites remove button
var favRemove = "Fjern";

//label for feedback
var feedback = "Feedback";

//url for feedback
var feedbackUrl = "";

//target window for feedback
var feedBackTarget = "_blank";

//label for toolbar forward button
var forward = "Videresend";

//label for glossay
var glossary = "Ordliste";

//url for glossary
var glossaryUrl = "";

//target window for glossary
var glossaryTarget = "_blank";

//label for toolbar hide/show
var hide = "Gem";

//label for "go to top toc"
var home = "Startside";

//url for "go to top toc"
var homeUrl = "index.html";

//label for index
var index = "Indeks";

//label for index enter field
var indexEnter = "Indtast den tekst, der skal s�ges:";

//label for index popup when no URL
var indexPopup = "V�lg et af underemnerne p� listen for at finde oplysninger om dette n�gleord.";

//label for pdf
var pdf = "Vis PDF";

//url for pdf
var pdfUrl = "";

//target window for pdf
var pdfTarget = "pdf";

//label for toolbar
var print = "Udskriv";

//label for search
var search = "S�g";

//search group, should be the same appears in mappingfile
var searchGroup = "Alle";

//Used for single package help system
var searchFile = "IPCmapping_sch.js";

//label for toolbar optional button
var seeAlso = "Valgfrit";

//url for toolbar optional button
var seeAlsoUrl = "";

//target for toolbar optional button
var seeAlsoTarget = "_blank";

//label for toolbar hide/show
var show = "Vis";

//default start page
var startPage = "ipcuggs1.html";
 
